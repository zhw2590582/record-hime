/*!
 * record-hime v1.0.1
 * Github: https://github.com/zhw2590582/record-hime
 * (c) 2018-2020 Harvey Zack
 * Released under the MIT License.
 */

!function(){"use strict";if(!document.querySelector(".record-hime")){var e=document.createElement("script");e.src=chrome.extension.getURL("injected/index.js"),document.head.appendChild(e);var t=document.createElement("link");t.rel="stylesheet",t.type="text/css",t.href=chrome.extension.getURL("injected/index.css"),document.head.appendChild(t)}}();
